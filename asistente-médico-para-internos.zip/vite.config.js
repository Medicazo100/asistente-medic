import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [
    react(),
  ],
  define: {
    'process.env.GEMINI_API_KEY': JSON.stringify(process.env.GEMINI_API_KEY),
    'process.env.API_KEY': JSON.stringify(process.env.API_KEY),
  },
  build: {
    target: "esnext", // pdfjs-dist uses top-level await
  },
  optimizeDeps: {
    esbuildOptions: {
      target: "esnext",
    },
  },
})